<main class="main">
    <?php echo isset($content) ? $content : NULL; ?>
</main>