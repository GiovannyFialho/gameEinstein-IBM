<div class="container-gamePage">
    <div class="container-game">
        <div class="container center">
            <div class="content-game">
                <form id="form-game">
                    <ul class="content-game-items">
                        <li class="content-game-items-item hasIndex">
                            <ul>
                                <li>Quem?</li>
                                <li>Veio Aprender</li>
                                <li>Perfil</li>
                                <li>Trabalha com</li>
                                <li>Empresa</li>
                            </ul>
                            <ul id="coluna1" class="coluna">
                                <li>
                                    <select id="quem1" name="quem1">
                                        <option selected hidden>Quem?</option>
                                        <option value="Baiana">Baiana</option>
                                        <option value="Catarinense">Catarinense</option>
                                        <option value="Goiana">Goiana</option>
                                        <option value="Mineira">Mineira</option>
                                        <option value="Paraense">Paraense</option>
                                    </select>
                                </li>
                                <li>
                                    <select id="veioAprender1" name="veioAprender1">
                                        <option selected hidden>Veio aprender</option>
                                        <option value="GRC">GRC</option>
                                        <option value="LGPD">LGPD</option>
                                        <option value="Machine Learning">Machine Learning</option>
                                        <option value="Open Source">Open Source</option>
                                        <option value="Solução Híbrida">Solução Híbrida</option>
                                    </select>
                                </li>
                                <li>
                                    <select id="perfil1" name="perfil1">
                                        <option selected hidden>Perfil</option>
                                        <option value="Analista">Analista</option>
                                        <option value="Coordenadora">Coordenadora</option>
                                        <option value="Diretora">Diretora</option>
                                        <option value="Estagiária">Estagiária</option>
                                        <option value="Gerente">Gerente</option>
                                    </select>
                                </li>
                                <li>
                                    <select id="trabalhaCom1" name="trabalhaCom1">
                                        <option selected hidden>Trabalha com</option>
                                        <option value="Automação">Automação</option>
                                        <option value="Data">Data</option>
                                        <option value="Infraestrutura">Infraestrutura</option>
                                        <option value="Inteligência Artificial">Inteligência Artificial</option>
                                        <option value="Segurança">Segurança</option>
                                    </select>
                                </li>
                                <li>
                                    <select id="empresa1" name="empresa1">
                                        <option selected hidden>Empresa</option>
                                        <option value="Empresa A">Empresa A</option>
                                        <option value="Empresa B">Empresa B</option>
                                        <option value="Empresa C">Empresa C</option>
                                        <option value="Empresa D">Empresa D</option>
                                        <option value="Empresa E">Empresa E</option>
                                    </select>
                                </li>
                            </ul>
                        </li>
                        <li class="content-game-items-item">
                            <ul id="coluna2" class="coluna">
                                <li>
                                    <select id="quem2" name="quem2">
                                        <option selected hidden>Quem?</option>
                                        <option value="Baiana">Baiana</option>
                                        <option value="Catarinense">Catarinense</option>
                                        <option value="Goiana">Goiana</option>
                                        <option value="Mineira">Mineira</option>
                                        <option value="Paraense">Paraense</option>
                                    </select>
                                </li>
                                <li>
                                    <select id="veioAprender2" name="veioAprender2">
                                        <option selected hidden>Veio aprender</option>
                                        <option value="GRC">GRC</option>
                                        <option value="LGPD">LGPD</option>
                                        <option value="Machine Learning">Machine Learning</option>
                                        <option value="Open Source">Open Source</option>
                                        <option value="Solução Híbrida">Solução Híbrida</option>
                                    </select>
                                </li>
                                <li>
                                    <select id="perfil2" name="perfil2">
                                        <option selected hidden>Perfil</option>
                                        <option value="Analista">Analista</option>
                                        <option value="Coordenadora">Coordenadora</option>
                                        <option value="Diretora">Diretora</option>
                                        <option value="Estagiária">Estagiária</option>
                                        <option value="Gerente">Gerente</option>
                                    </select>
                                </li>
                                <li>
                                    <select id="trabalhaCom2" name="trabalhaCom2">
                                        <option selected hidden>Trabalha com</option>
                                        <option value="Automação">Automação</option>
                                        <option value="Data">Data</option>
                                        <option value="Infraestrutura">Infraestrutura</option>
                                        <option value="Inteligência Artificial">Inteligência Artificial</option>
                                        <option value="Segurança">Segurança</option>
                                    </select>
                                </li>
                                <li>
                                    <select id="empresa2" name="empresa2">
                                        <option selected hidden>Empresa</option>
                                        <option value="Empresa A">Empresa A</option>
                                        <option value="Empresa B">Empresa B</option>
                                        <option value="Empresa C">Empresa C</option>
                                        <option value="Empresa D">Empresa D</option>
                                        <option value="Empresa E">Empresa E</option>
                                    </select>
                                </li>
                            </ul>
                        </li>
                        <li class="content-game-items-item">
                            <ul id="coluna3" class="coluna">
                                <li>
                                    <select id="quem3" name="quem3">
                                        <option selected hidden>Quem?</option>
                                        <option value="Baiana">Baiana</option>
                                        <option value="Catarinense">Catarinense</option>
                                        <option value="Goiana">Goiana</option>
                                        <option value="Mineira">Mineira</option>
                                        <option value="Paraense">Paraense</option>
                                    </select>
                                </li>
                                <li>
                                    <select id="veioAprender3" name="veioAprender3">
                                        <option selected hidden>Veio aprender</option>
                                        <option value="GRC">GRC</option>
                                        <option value="LGPD">LGPD</option>
                                        <option value="Machine Learning">Machine Learning</option>
                                        <option value="Open Source">Open Source</option>
                                        <option value="Solução Híbrida">Solução Híbrida</option>
                                    </select>
                                </li>
                                <li>
                                    <select id="perfil3" name="perfil3">
                                        <option selected hidden>Perfil</option>
                                        <option value="Analista">Analista</option>
                                        <option value="Coordenadora">Coordenadora</option>
                                        <option value="Diretora">Diretora</option>
                                        <option value="Estagiária">Estagiária</option>
                                        <option value="Gerente">Gerente</option>
                                    </select>
                                </li>
                                <li>
                                    <select id="trabalhaCom3" name="trabalhaCom3">
                                        <option selected hidden>Trabalha com</option>
                                        <option value="Automação">Automação</option>
                                        <option value="Data">Data</option>
                                        <option value="Infraestrutura">Infraestrutura</option>
                                        <option value="Inteligência Artificial">Inteligência Artificial</option>
                                        <option value="Segurança">Segurança</option>
                                    </select>
                                </li>
                                <li>
                                    <select id="empresa3" name="empresa3">
                                        <option selected hidden>Empresa</option>
                                        <option value="Empresa A">Empresa A</option>
                                        <option value="Empresa B">Empresa B</option>
                                        <option value="Empresa C">Empresa C</option>
                                        <option value="Empresa D">Empresa D</option>
                                        <option value="Empresa E">Empresa E</option>
                                    </select>
                                </li>
                            </ul>
                        </li>
                        <li class="content-game-items-item">
                            <ul id="coluna4" class="coluna">
                                <li>
                                    <select id="quem4" name="quem4">
                                        <option selected hidden>Quem?</option>
                                        <option value="Baiana">Baiana</option>
                                        <option value="Catarinense">Catarinense</option>
                                        <option value="Goiana">Goiana</option>
                                        <option value="Mineira">Mineira</option>
                                        <option value="Paraense">Paraense</option>
                                    </select>
                                </li>
                                <li>
                                    <select id="veioAprender4" name="veioAprender4">
                                        <option selected hidden>Veio aprender</option>
                                        <option value="GRC">GRC</option>
                                        <option value="LGPD">LGPD</option>
                                        <option value="Machine Learning">Machine Learning</option>
                                        <option value="Open Source">Open Source</option>
                                        <option value="Solução Híbrida">Solução Híbrida</option>
                                    </select>
                                </li>
                                <li>
                                    <select id="perfil4" name="perfil4">
                                        <option selected hidden>Perfil</option>
                                        <option value="Analista">Analista</option>
                                        <option value="Coordenadora">Coordenadora</option>
                                        <option value="Diretora">Diretora</option>
                                        <option value="Estagiária">Estagiária</option>
                                        <option value="Gerente">Gerente</option>
                                    </select>
                                </li>
                                <li>
                                    <select id="trabalhaCom4" name="trabalhaCom4">
                                        <option selected hidden>Trabalha com</option>
                                        <option value="Automação">Automação</option>
                                        <option value="Data">Data</option>
                                        <option value="Infraestrutura">Infraestrutura</option>
                                        <option value="Inteligência Artificial">Inteligência Artificial</option>
                                        <option value="Segurança">Segurança</option>
                                    </select>
                                </li>
                                <li>
                                    <select id="empresa4" name="empresa4">
                                        <option selected hidden>Empresa</option>
                                        <option value="Empresa A">Empresa A</option>
                                        <option value="Empresa B">Empresa B</option>
                                        <option value="Empresa C">Empresa C</option>
                                        <option value="Empresa D">Empresa D</option>
                                        <option value="Empresa E">Empresa E</option>
                                    </select>
                                </li>
                            </ul>
                        </li>
                        <li class="content-game-items-item">
                            <ul id="coluna5" class="coluna">
                                <li>
                                    <select id="quem5" name="quem5">
                                        <option selected hidden>Quem?</option>
                                        <option value="Baiana">Baiana</option>
                                        <option value="Catarinense">Catarinense</option>
                                        <option value="Goiana">Goiana</option>
                                        <option value="Mineira">Mineira</option>
                                        <option value="Paraense">Paraense</option>
                                    </select>
                                </li>
                                <li>
                                    <select id="veioAprender5" name="veioAprender5">
                                        <option selected hidden>Veio aprender</option>
                                        <option value="GRC">GRC</option>
                                        <option value="LGPD">LGPD</option>
                                        <option value="Machine Learning">Machine Learning</option>
                                        <option value="Open Source">Open Source</option>
                                        <option value="Solução Híbrida">Solução Híbrida</option>
                                    </select>
                                </li>
                                <li>
                                    <select id="perfil5" name="perfil5">
                                        <option selected hidden>Perfil</option>
                                        <option value="Analista">Analista</option>
                                        <option value="Coordenadora">Coordenadora</option>
                                        <option value="Diretora">Diretora</option>
                                        <option value="Estagiária">Estagiária</option>
                                        <option value="Gerente">Gerente</option>
                                    </select>
                                </li>
                                <li>
                                    <select id="trabalhaCom5" name="trabalhaCom5">
                                        <option selected hidden>Trabalha com</option>
                                        <option value="Automação">Automação</option>
                                        <option value="Data">Data</option>
                                        <option value="Infraestrutura">Infraestrutura</option>
                                        <option value="Inteligência Artificial">Inteligência Artificial</option>
                                        <option value="Segurança">Segurança</option>
                                    </select>
                                </li>
                                <li>
                                    <select id="empresa5" name="empresa5">
                                        <option selected hidden>Empresa</option>
                                        <option value="Empresa A">Empresa A</option>
                                        <option value="Empresa B">Empresa B</option>
                                        <option value="Empresa C">Empresa C</option>
                                        <option value="Empresa D">Empresa D</option>
                                        <option value="Empresa E">Empresa E</option>
                                    </select>
                                </li>
                            </ul>
                        </li>
                    </ul>
                    <div class="form-footer">
                        <div class="container-buttons">
                            <div class="button-container">
                                <button>
                                    Registrar desafio
                                    <span class="icon">
                                        <svg focusable="false" preserveAspectRatio="xMidYMid meet" xmlns="http://www.w3.org/2000/svg" fill="currentColor" aria-label="Open resource" width="20" height="20" viewBox="0 0 32 32" role="img"><path d="M26,28H6a2.0027,2.0027,0,0,1-2-2V6A2.0027,2.0027,0,0,1,6,4H16V6H6V26H26V16h2V26A2.0027,2.0027,0,0,1,26,28Z"></path><path d="M20 2L20 4 26.586 4 18 12.586 19.414 14 28 5.414 28 12 30 12 30 2 20 2z"></path></svg>
                                    </span>
                                </button>
                            </div>
                            <div class="button-container">
                                <div class="button" onclick="euDesisto()">
                                    <p>Ok, eu desisto</p>
                                    <span class="icon">
                                        <svg focusable="false" preserveAspectRatio="xMidYMid meet" xmlns="http://www.w3.org/2000/svg" fill="currentColor" aria-label="Open resource" width="20" height="20" viewBox="0 0 32 32" role="img"><path d="M26,28H6a2.0027,2.0027,0,0,1-2-2V6A2.0027,2.0027,0,0,1,6,4H16V6H6V26H26V16h2V26A2.0027,2.0027,0,0,1,26,28Z"></path><path d="M20 2L20 4 26.586 4 18 12.586 19.414 14 28 5.414 28 12 30 12 30 2 20 2z"></path></svg>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="cronometro">
                            <div class="wind">
                                <p>
                                    Tempo
                                    <span id="minutes">00</span>: <span id="seconds">00</span>
                                </p>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="container-gameTips">
        <div class="container center">
            <div class="content-tips">
                <ul>
                    <li>
                        <input type="checkbox" id="isGRC" name="isGRC" disabled>
                        <label for="isGRC">Quem veio aprender sobre <span class="important">GRC (Governance Risk and Compliance)</span> está na primeira coluna</label>
                    </li>
                    <li>
                        <input type="checkbox" id="isOpenSource" name="isOpenSource" disabled>
                        <label for="isOpenSource">Quem veio aprender <span class="important">Open Source</span> está na terceira coluna</label>
                    </li>
                    <li>
                        <input type="checkbox" id="isSolucaoHibrida" name="isSolucaoHibrida" disabled>
                        <label for="isSolucaoHibrida">Quem veio aprender sobre <span class="important">Solução Híbrida</span> trabalha na <span class="important">empresa A</span></label>
                    </li>
                    <li>
                        <input type="checkbox" id="isLGPD" name="isLGPD" disabled>
                        <label for="isLGPD">Quem veio aprender sobre <span class="important">LGPD</span> é <span class="important">analista</span></label>
                    </li>
                    <li>
                        <input type="checkbox" id="isBaiana" name="isBaiana" disabled>
                        <label for="isBaiana">A <span class="important">baiana</span> está do lado esquerdo da <span class="important">goiana</span></label>
                    </li>
                    <li>
                        <input type="checkbox" id="isBaianaCargo" name="isBaianaCargo" disabled>
                        <label for="isBaianaCargo">A <span class="important">baiana</span> é <span class="important">gerente</span></label>
                    </li>
                    <li>
                        <input type="checkbox" id="isSeguranca" name="isSeguranca" disabled>
                        <label for="isSeguranca">Quem trabalha com <span class="important">segurança</span>, trabalha na <span class="important">empresa D</span></label>
                    </li>
                    <li>
                        <input type="checkbox" id="isMineiraCargo" name="isMineiraCargo" disabled>
                        <label for="isMineiraCargo">A <span class="important">mineira</span> trabalha com <span class="important">automação</span></label>
                    </li>
                    <li>
                        <input type="checkbox" id="isDiretora" name="isDiretora" disabled>
                        <label for="isDiretora">Quem está na terceira coluna é <span class="important">diretora</span></label>
                    </li>
                    <li>
                        <input type="checkbox" id="isInteligenciaArtificial" name="isInteligenciaArtificial" disabled>
                        <label for="isInteligenciaArtificial">Quem trabalha com <span class="important">inteligência artificial</span>, está do lado de quem trabalha na <span class="important">empresa C</span></label>
                    </li>
                    <li>
                        <input type="checkbox" id="isEmpresaB" name="isEmpresaB" disabled>
                        <label for="isEmpresaB">Quem trabalha na <span class="important">empresa B</span>, está do lado de quem trabalha com <span class="important">automação</span></label>
                    </li>
                    <li>
                        <input type="checkbox" id="isData" name="isData" disabled>
                        <label for="isData">Quem trabalha com <span class="important">Data</span>, é <span class="important">coordenadora</span></label>
                    </li>
                    <li>
                        <input type="checkbox" id="isMachineLearging" name="isMachineLearging" disabled>
                        <label for="isMachineLearging">Quem veio aprender sobre <span class="important">machine learning</span>, trabalha com <span class="important">infraestrutura</span></label>
                    </li>
                    <li>
                        <input type="checkbox" id="isParaense" name="isParaense" disabled>
                        <label for="isParaense">Quem veio aprender sobre <span class="important">GRC (Governance Risk and Compliance)</span> esta ao lado da <span class="important">paraense.</span></label>
                    </li>
                    <li>
                        <input type="checkbox" id="isEstagiaria" name="isEstagiaria" disabled>
                        <label for="isEstagiaria">Quem trabalha com <span class="important">inteligência artificial</span> está do lado da <span class="important">estagiária</span></label>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>

<div class="container-popup">
    <div class="popup-info"></div>
</div>
