<div class="container-padrao fullpage">
    <div class="container center no-center-mobile">
        <div class="ranking-container" id="ranking"></div>
    </div>
</div>
