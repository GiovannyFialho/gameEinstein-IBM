<?php echo isset($content) ? $content : null; ?>
