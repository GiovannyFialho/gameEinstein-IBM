# Game Einstein - IBM 👾

## Install dependencies

```
yarn
```

## Rodar PHP

```
docker-compose up -d
```
